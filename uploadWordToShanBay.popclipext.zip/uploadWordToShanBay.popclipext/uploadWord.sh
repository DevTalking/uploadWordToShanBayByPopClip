wordId=`curl https://api.shanbay.com/bdc/search/\?word\=$POPCLIP_TEXT | jq .data.id`
curl --data "id=$wordId" --header "Authorization: Bearer TOKEN" https://api.shanbay.com/bdc/learning/
